/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package kalkulatortrapesium;

/**
 *
 * @author ACER
 */
public interface Geometri2D {
    double hitungLuas();
    double hitungKeliling();
}
